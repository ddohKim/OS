
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "list.h"
#include "hash.h"
#include "bitmap.h"

void hash_action_destroy(struct hash_elem *e, void *aux)
{
    struct hash_item *item;
    item = hash_entry(e, struct hash_item, elem);
    free(item);
}
void hash_square(struct hash_elem *e, void *aux)
{
    struct hash_item *item;
    item = hash_entry(e, struct hash_item, elem);
    item->data = (item->data) * (item->data);
}
void hash_triple(struct hash_elem *e, void *aux)
{
    struct hash_item *item;
    item = hash_entry(e, struct hash_item, elem);
    item->data = (item->data) * (item->data) * (item->data);
}
unsigned hash_hash(const struct hash_elem *e, void *aux)
{
    struct hash_item *item = hash_entry(e, struct hash_item, elem);
    return hash_int(item->data);
}
bool list_less(const struct list_elem *a, const struct list_elem *b, void *aux)
{
    struct list_item *item1, *item2;
    item1 = list_entry(a, struct list_item, elem);
    item2 = list_entry(b, struct list_item, elem);
    if ((item1->data) >= (item2->data))
        return false;
    else
        return true;
}

bool hash_less(const struct hash_elem *a, const struct hash_elem *b, void *aux)
{
    struct hash_item *item1, *item2;
    item1 = hash_entry(a, struct hash_item, elem);
    item2 = hash_entry(b, struct hash_item, elem);
    if ((item1->data) >= (item2->data))
        return false;
    else
        return true;
}

int space = 0;
int space2 = 0;
int space3 = 0;
int list_count = 0;
int hash_count = 0;
int bit_count = 0;
void list(char *input)
{
    int i = 1;
    char *ptr = strtok(input, " _");
    char list_input[10][10] = {
        '\0',
    };
    strcpy(list_input[0], ptr);
    while (1)
    {
        ptr = strtok(NULL, " _");
        if (ptr == NULL)
            break;
        strcpy(list_input[i], ptr);
        i++;
    }

    if (strcmp(list_input[1], "push") == 0 && strcmp(list_input[2], "front") == 0)
    {

        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[3], node_list[i].name) == 0)
                break;
        }
        struct list_item *item = (struct list_item *)malloc(sizeof(struct list_item));

        item = list_entry(&(item->elem), struct list_item, elem);

        item->data = atoi(list_input[4]);

        list_push_front(node_list[i].list, &item->elem);
    }
    else if (strcmp(list_input[1], "insert") == 0 && strcmp(list_input[2], "ordered") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[3], node_list[i].name) == 0)
                break;
        }

        struct list_item *item = (struct list_item *)malloc(sizeof(struct list_item));
        item->data = atoi(list_input[4]);
        item = list_entry(&(item->elem), struct list_item, elem);
        list_insert_ordered(node_list[i].list, &(item->elem), list_less, NULL);
    }

    else if (strcmp(list_input[1], "swap") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        struct list_elem *element1, *element2;

        element1 = list_begin(node_list[i].list);

        element2 = list_begin(node_list[i].list);

        int k = 0;
        while (k < atoi(list_input[3]))
        {
            k++;
            element1 = list_next(element1);
        }
        k = 0;
        while (k < atoi(list_input[4]))
        {
            k++;
            element2 = list_next(element2);
        }
        list_swap(element1, element2);
    }
    else if (strcmp(list_input[1], "shuffle") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        list_shuffle(node_list[i].list);
    }
    else if (strcmp(list_input[1], "insert") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        struct list_item *item = (struct list_item *)malloc(sizeof(struct list_item));

        item = list_entry(&(item->elem), struct list_item, elem);
        struct list_elem *prev = list_begin(node_list[i].list);
        int j = 0;
        while (j < atoi(list_input[3]))
        {
            j++;
            prev = list_next(prev);
        }
        item = list_entry(&(item->elem), struct list_item, elem);
        item->data = atoi(list_input[4]);
        list_insert(prev, &item->elem);
    }

    else if (strcmp(list_input[1], "remove") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        struct list_elem *temp = list_head(node_list[i].list);
        for (int j = 0; j <= atoi(list_input[3]); j++)
        {
            temp = temp->next;
        }
        list_remove(temp);
    }

    else if (strcmp(list_input[1], "reverse") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        list_reverse(node_list[i].list);
    }
    else if (strcmp(list_input[1], "sort") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }

        struct list_elem *element = list_begin(node_list[i].list);
        list_sort(node_list[i].list, list_less, NULL);
    }

    else if (strcmp(list_input[1], "unique") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        if (list_input[3][0] == '\0')
        {
            list_unique(node_list[i].list, NULL, list_less, NULL);
        }
        else
        {
            int j;
            for (j = 0; j < 20; j++)
            {
                if (strcmp(list_input[3], node_list[j].name) == 0)
                    break;
            }

            list_unique(node_list[i].list, node_list[j].list, list_less, NULL);
        }
    }
    else if (strcmp(list_input[1], "empty") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        if (list_empty(node_list[i].list))
        {
            printf("true\n");
        }
        else
            printf("false\n");
    }
    else if (strcmp(list_input[1], "size") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        printf("%zu\n", list_size(node_list->list));
    }
    else if (strcmp(list_input[1], "max") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        struct list_elem *element = (struct list_elem *)malloc(sizeof(struct list_elem));
        struct list_item *item = (struct list_item *)malloc(sizeof(struct list_item));
        element = list_max(node_list[i].list, list_less, NULL);
        item = list_entry(element, struct list_item, elem);
        printf("%d\n", item->data);
    }
    else if (strcmp(list_input[1], "min") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        struct list_elem *element = (struct list_elem *)malloc(sizeof(struct list_elem));
        struct list_item *item = (struct list_item *)malloc(sizeof(struct list_item));
        element = list_min(node_list[i].list, list_less, NULL);
        item = list_entry(element, struct list_item, elem);
        printf("%d", item->data);
        if (space2 == 0)
            printf("\n");
        space2 = 1;
    }

    else if (strcmp(list_input[1], "splice") == 0)
    {
        struct list_elem *first, *end, *temp;
        int i, j;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        for (j = 0; j < 20; j++)
        {
            if (strcmp(list_input[4], node_list[j].name) == 0)
                break;
        }
        temp = list_begin(node_list[i].list);

        int k = 0;
        while (k < atoi(list_input[3]))
        {
            k++;
            temp = list_next(temp);
        }
        k = 0;
        first = list_begin(node_list[j].list);
        while (k < atoi(list_input[5]))
        {
            k++;
            first = list_next(first);
        }
        k = 0;
        end = list_begin(node_list[j].list);
        while (k < atoi(list_input[6]))
        {
            k++;
            end = list_next(end);
        }
        list_splice(temp, first, end);
    }

    else if (strcmp(list_input[1], "push") == 0 && strcmp(list_input[2], "back") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[3], node_list[i].name) == 0)
                break;
        }
        struct list_item *item = (struct list_item *)malloc(sizeof(struct list_item));
        struct list_elem *temp = list_begin(node_list[i].list);
        for (int j = 0; j < atoi(list_input[2]); j++)
        {
            temp = list_next(temp);
        }

        item = list_entry(&(item->elem), struct list_item, elem);
        item->data = atoi(list_input[4]);

        list_push_back(node_list[i].list, &item->elem);
    }
    else if (strcmp(list_input[1], "front") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        struct list_elem *element;
        element = list_front(node_list[i].list);
        struct list_item *data;
        data = list_entry(element, struct list_item, elem);
        printf("%d", data->data);
    }
    else if (strcmp(list_input[1], "back") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[2], node_list[i].name) == 0)
                break;
        }
        struct list_elem *element;
        element = list_back(node_list[i].list);
        struct list_item *data;
        data = list_entry(element, struct list_item, elem);
        printf("%d", data->data);
    }

    else if (strcmp(list_input[1], "pop") == 0 && strcmp(list_input[2], "front") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[3], node_list[i].name) == 0)
                break;
        }
        list_pop_front(node_list[i].list);
    }
    else if (strcmp(list_input[1], "pop") == 0 && strcmp(list_input[2], "back") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(list_input[3], node_list[i].name) == 0)
                break;
        }
        list_pop_back(node_list[i].list);
    }
}

void create(char *input)
{

    int i = 1;
    char *ptr = strtok(input, " ");
    char list_create[10][10] = {
        '\0',
    };
    strcpy(list_create[0], ptr);
    while (1)
    {
        ptr = strtok(NULL, " ");
        if (ptr == NULL)
            break;
        strcpy(list_create[i], ptr);
        i++;
    }
    if (strcmp(list_create[1], "list") == 0)
    {

        if (strncmp(list_create[2], "list", 4) == 0)
        {
            node_list[list_count].list = (struct list *)malloc(sizeof(struct list));
            list_init(node_list[list_count].list);
            strcpy(node_list[list_count].name, list_create[2]);
            list_count++;
        }
    }
    if (strcmp(list_create[1], "hashtable") == 0)
    {
        hash_table[hash_count].hash = (struct hash *)malloc(sizeof(struct hash));
        hash_init(hash_table[hash_count].hash, hash_hash, hash_less, NULL);
        strcpy(hash_table[hash_count].name, list_create[2]);
        hash_count++;
    }
    if (strcmp(list_create[1], "bitmap") == 0)
    {
        strcpy(bitmap_array[bit_count].name, list_create[2]);
        size_t num_of_bit = atoi(list_create[3]);
        bitmap_array[bit_count].bit = bitmap_create(num_of_bit);
        bit_count++;
    }
}
void dumpdata(char *input)
{
    if (space != 0)
        printf("\n");
    char *ptr = strtok(input, " ");
    ptr = strtok(NULL, " ");
    if (strncmp(ptr, "list", 4) == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(ptr, node_list[i].name) == 0)
                break;
        }
        struct list_elem *element = list_begin(node_list[i].list);
        while (1)
        {
            struct list_item *data = list_entry(element, struct list_item, elem);
            if (element == list_end(node_list[i].list))
                break;
            printf("%d", data->data);
            space = 1;

            element = list_next(element);
            if (element != list_end(node_list[i].list))
            {
                printf(" ");
            }
        }
    }
    else if (strncmp(ptr, "bm", 2) == 0)
    {
        if (space != 0)
            printf("\n");

        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(ptr, bitmap_array[i].name) == 0)
                break;
        }
        int k = 0;
        while (1)
        {
            if (k == bitmap_size(bitmap_array[i].bit))
                break;
            k++;
            if (bitmap_test(bitmap_array[i].bit, k - 1) == 1)
                printf("1");
            else
                printf("0");
        }
        space = 1;
    }
    else if (strncmp(ptr, "hash", 4) == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(ptr, hash_table[i].name) == 0)
                break;
        }
        struct list_elem *element;
        int k = 0;

        while (1)
        {

            if (k == hash_table[i].hash->bucket_cnt)
            {
                break;
            }
            element = list_begin(&(hash_table[i].hash->buckets[k]));

            while (1)
            {
                if (element == list_end(&(hash_table[i].hash->buckets[k])))
                    break;
                struct hash_elem *elem = list_entry(element, struct hash_elem, list_elem);
                struct hash_item *item = hash_entry(elem, struct hash_item, elem);
                printf("%d ", item->data);
                space = 1;
                element = list_next(element);
            }
            k++;
        }
    }
}

void delete (char *input)
{
    char *ptr = strtok(input, " ");
    ptr = strtok(NULL, " ");
    if (strncmp(ptr, "list", 4) == 0)
    {
        int i = 0;
        while (1)
        {
            if (strcmp(ptr, node_list[i].name) == 0)
            {
                for (int j = i; j < 20; j++)
                {
                    node_list[j] = node_list[j + 1];
                }
                list_count--;
                break;
            }
            i++;
        }
    }
    if (strncmp(ptr, "hash", 4) == 0)
    {
        int i = 0;
        while (1)
        {
            if (strcmp(ptr, hash_table[i].name) == 0)
            {
                hash_destroy(hash_table[i].hash, hash_action_destroy);
                break;
            }
            hash_count--;
            i++;
        }
    }
}

void hash(char *input)
{
    int i = 1;
    char *ptr = strtok(input, " _");
    char hash_input[10][10] = {
        '\0',
    };
    strcpy(hash_input[0], ptr);
    while (1)
    {
        ptr = strtok(NULL, " _");
        if (ptr == NULL)
            break;
        strcpy(hash_input[i], ptr);
        i++;
    }
    if (strcmp(hash_input[1], "insert") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(hash_input[2], hash_table[i].name) == 0)
                break;
        }
        struct hash_item *item = (struct hash_item *)malloc(sizeof(struct hash_item));
        struct hash_elem *element = (struct hash_elem *)malloc(sizeof(struct hash_elem));
        item = hash_entry(element, struct hash_item, elem);
        item->data = atoi(hash_input[3]);
        hash_insert(hash_table[i].hash, element);
    }
    else if (strcmp(hash_input[1], "replace") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(hash_input[2], hash_table[i].name) == 0)
                break;
        }
        struct hash_item *item = (struct hash_item *)malloc(sizeof(struct hash_item));
        struct hash_elem *element = (struct hash_elem *)malloc(sizeof(struct hash_elem));
        item = hash_entry(element, struct hash_item, elem);
        item->data = atoi(hash_input[3]);
        hash_replace(hash_table[i].hash, element);
    }
    else if (strcmp(hash_input[1], "apply") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(hash_input[2], hash_table[i].name) == 0)
                break;
        }
        if (strcmp(hash_input[3], "triple") == 0)
        {
            hash_apply(hash_table[i].hash, hash_triple);
        }
        else if (strcmp(hash_input[3], "square") == 0)
        {
            hash_apply(hash_table[i].hash, hash_square);
        }
    }

    else if (strcmp(hash_input[1], "delete") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(hash_input[2], hash_table[i].name) == 0)
                break;
        }
        struct hash_item *item = (struct hash_item *)malloc(sizeof(struct hash_item));
        struct hash_elem *element = (struct hash_elem *)malloc(sizeof(struct hash_elem));
        item->data = atoi(hash_input[3]);
        element = hash_delete(hash_table[i].hash, &item->elem);
    }
    else if (strcmp(hash_input[1], "find") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(hash_input[2], hash_table[i].name) == 0)
                break;
        }
        struct hash_item *item = (struct hash_item *)malloc(sizeof(struct hash_item));
        struct hash_elem *element = (struct hash_elem *)malloc(sizeof(struct hash_elem));
        item->data = atoi(hash_input[3]);
        element = hash_find(hash_table[i].hash, &item->elem);
        if (element == NULL)
        {
        }
        else
        {
            printf("%d", item->data);
        }
    }
    else if (strcmp(hash_input[1], "empty") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(hash_input[2], hash_table[i].name) == 0)
                break;
        }
        if (hash_empty(hash_table[i].hash))
            printf("true");
        else
            printf("false");
        space = 1;
    }
    else if (strcmp(hash_input[1], "clear") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(hash_input[2], hash_table[i].name) == 0)
                break;
        }
        hash_clear(hash_table[i].hash, hash_action_destroy);
    }
    else if (strcmp(hash_input[1], "size") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(hash_input[2], hash_table[i].name) == 0)
                break;
        }
        printf("%zu", hash_size(hash_table[i].hash));
    }
}
void bitmap(char *input)
{
    int i = 1;
    char *ptr = strtok(input, " _");
    char bit_input[10][10] = {
        '\0',
    };
    strcpy(bit_input[0], ptr);
    while (1)
    {
        ptr = strtok(NULL, " _");
        if (ptr == NULL)
            break;
        strcpy(bit_input[i], ptr);
        i++;
    }
    if (strcmp(bit_input[1], "mark") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
        bitmap_mark(bitmap_array[i].bit, atoi(bit_input[3]));
    }
    else if (strcmp(bit_input[1], "dump") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }

        bitmap_dump(bitmap_array[i].bit);
    }
    else if (strcmp(bit_input[1], "size") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
size_t size;
        size=bitmap_size(bitmap_array[i].bit);
        printf("%zu\n",size);
    }
    else if (strcmp(bit_input[1], "test") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
bool test=bitmap_test(bitmap_array[i].bit,atoi(bit_input[3]));
if(!test)printf("false\n");
else printf("true\n");
    }
    else if (strcmp(bit_input[1], "expand") == 0){
                 int i;
               for (i = 0; i < 20; i++)
               {
                   if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                       break;
               }
               
              bitmap_array[i].bit=bitmap_expand(bitmap_array[i].bit,atoi(bit_input[3]));
          }

    else if (strcmp(bit_input[1], "scan") == 0 && strcmp(bit_input[2], "and") == 1)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
        bool scan = 0;
        if (strcmp(bit_input[5], "true") == 0)
            scan = 1;
        space = 0;
        size_t num = bitmap_scan(bitmap_array[i].bit, atoi(bit_input[3]), atoi(bit_input[4]), scan);
        printf("%zu\n", num);
    }
    else if (strcmp(bit_input[1], "scan") == 0 && strcmp(bit_input[2], "and") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[4], bitmap_array[i].name) == 0)
                break;
        }
        bool scan = 0;
        if (strcmp(bit_input[7], "true") == 0)
            scan = 1;
        space = 0;
        size_t num = bitmap_scan_and_flip(bitmap_array[i].bit, atoi(bit_input[5]), atoi(bit_input[6]), scan);
        printf("%zu\n", num);
    }
    else if (strcmp(bit_input[1], "flip") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
        bitmap_flip(bitmap_array[i].bit, atoi(bit_input[3]));
    }

else if (strcmp(bit_input[1], "reset") == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
        bitmap_reset(bitmap_array[i].bit, atoi(bit_input[3]));
    }
else if (strcmp(bit_input[1], "set") == 0&&strcmp(bit_input[2],"all")==0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[3], bitmap_array[i].name) == 0)
                break;
        }
        bool check=0;
        if(strcmp(bit_input[4],"true")==0) check=1;
        bitmap_set_all(bitmap_array[i].bit, check);
    }
else if (strcmp(bit_input[1], "set") == 0&&strcmp(bit_input[2],"all")!=0&&strcmp(bit_input[2],"multiple")!=0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
        bool check=0;
         if(strcmp(bit_input[4],"true")==0)  check=1;
        bitmap_set(bitmap_array[i].bit,atoi(bit_input[3]),check);
    }
else if (strcmp(bit_input[1], "set") == 0&&strcmp(bit_input[2],"multiple")==0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[3], bitmap_array[i].name) == 0)
                break;
        }
        bool check=0;
        if(strcmp(bit_input[6],"true")==0) check=1;
        bitmap_set_multiple(bitmap_array[i].bit,atoi(bit_input[4]),atoi(bit_input[5]),check);
    }

else if (strcmp(bit_input[1], "none") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
        if (bitmap_none(bitmap_array[i].bit, atoi(bit_input[3]), atoi(bit_input[4])) == 1)
            printf("true\n");
        else
            printf("false\n");
    }
    else if (strcmp(bit_input[1], "all") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
        if (bitmap_all(bitmap_array[i].bit, atoi(bit_input[3]), atoi(bit_input[4])) == 1)
            printf("true\n");
        else
            printf("false\n");
    }
    else if (strcmp(bit_input[1], "any") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
        if (bitmap_any(bitmap_array[i].bit, atoi(bit_input[3]), atoi(bit_input[4])) == 1)
            printf("true\n");
        else
            printf("false\n");
    }

    else if (strcmp(bit_input[1], "contains") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
        bool contain = 0;
        if (strcmp(bit_input[5], "true") == 0)
            contain = 1;
        space = 0;
        if (bitmap_contains(bitmap_array[i].bit, atoi(bit_input[3]), atoi(bit_input[4]), contain) == 1)
            printf("true\n");
        else
            printf("false\n");
    }
    else if (strcmp(bit_input[1], "count") == 0)
    {
        if (space != 0)
            printf("\n");
        int i;
        for (i = 0; i < 20; i++)
        {
            if (strcmp(bit_input[2], bitmap_array[i].name) == 0)
                break;
        }
        bool type = 0;
        if (strcmp(bit_input[5], "true") == 0)
            type = 1;
        space = 0;
        size_t count = bitmap_count(bitmap_array[i].bit, atoi(bit_input[3]), atoi(bit_input[4]), type);
        printf("%zu\n", count);
    }
}

int main()
{

    while (1)
    {
        char input[100];
        fgets(input, 100, stdin);
        // scanf("%[^\n]s",input);
        input[strlen(input) - 1] = '\0';
        if (strcmp(input, "quit") == 0)
            return 0;
        else if (!strncmp(input, "create", 6))
            create(input);
        else if (!strncmp(input, "dumpdata", 8))
            dumpdata(input);
        else if (!strncmp(input, "delete", 6))
            delete (input);
        else if (!strncmp(input, "list", 4))
            list(input);
        else if (!strncmp(input, "hash", 4))
            hash(input);
        else if (!strncmp(input, "bitmap", 6))
            bitmap(input);
    }
    return 0;
}
